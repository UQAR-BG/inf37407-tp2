from django.apps import AppConfig


class QuestionwordsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'questionWords'
